package Assignment2;

public class Test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
