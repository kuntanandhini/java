package Assignment2;

public class Test8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
